// API key
const API_KEY = "pk.eyJ1IjoiY3Jpc2Jhbmdhb2lsIiwiYSI6ImNqczE4OXRpYjFyeDIzeW8zd3ZzMWtxYnEifQ.zZTZuPY6vF9N7cGsrjhwWw";
